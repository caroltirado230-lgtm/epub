const CACHE_NAME = 'pdf-epub-app-v7';
const APP_SHELL = [
  './',
  './index.html',
  './app.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './vendor/jszip.min.js',
  './vendor/pdf.min.js',
  './vendor/pdf.worker.min.js'
];

// Archivos que pueden faltar sin romper la instalación (si no se pueden guardar, se omiten).
// El resto es imprescindible: si falla alguno, se conserva la versión anterior.
const OPTIONAL = ['./', './index.html', './icon-maskable-512.png'];

self.addEventListener('install', (event) => {
  // Netlify puede redirigir /app.html → /app; guardamos una copia "limpia" (sin redirección)
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(
        APP_SHELL.map((url) =>
          fetch(url, { cache: 'reload' }).then(async (res) => {
            if (!res.ok) throw new Error('No se pudo guardar ' + url);
            const clean = res.redirected
              ? new Response(await res.blob(), { status: res.status, headers: res.headers })
              : res;
            await cache.put(url, clean.clone());
            if (url === './app.html') await cache.put('./app', clean);
          }).catch((err) => { if (!OPTIONAL.includes(url)) throw err; })
        )
      )
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

function putInCache(request, response) {
  if (response && !response.redirected && (response.ok || response.type === 'opaque')) {
    const copy = response.clone();
    caches.open(CACHE_NAME).then((cache) => cache.put(request, copy)).catch(() => {});
  }
  return response;
}

// Si Android dice "conectado" pero no hay Internet real, ninguna petición debe dejar
// la app esperando: todas tienen tiempo límite.
function fetchWithTimeout(request, ms = 4000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return fetch(request, { signal: controller.signal }).finally(() => clearTimeout(timer));
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  // Páginas: se sirve la copia guardada AL INSTANTE y se actualiza en segundo plano
  // (la siguiente visita ya trae la versión nueva). Sin copia, red con tiempo límite.
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match(req, { ignoreSearch: true }).then((cached) => {
        const update = fetchWithTimeout(req).then((res) => putInCache(req, res)).catch(() => null);
        if (cached) { event.waitUntil(update); return cached; }
        return update.then((res) => {
          if (res) return res;
          const path = new URL(req.url).pathname;
          return caches.match(/\/app(\.html)?$/.test(path) ? './app.html' : './index.html');
        });
      })
    );
    return;
  }

  // Resto (librerías, iconos, fuentes): primero la caché; si no, red con tiempo límite.
  // Las fuentes externas (3 s) que no cargan simplemente se omiten: se usa la fuente de reserva.
  const external = new URL(req.url).origin !== self.location.origin;
  event.respondWith(
    caches.match(req).then((cached) =>
      cached || fetchWithTimeout(req, external ? 3000 : 4000).then((res) => putInCache(req, res))
    )
  );
});
