# AGENTS.md

## Arquitectura
Sitio estático sin compilación, publicado desde `public/` (ver `netlify.toml`). Todo el procesamiento ocurre en el cliente; no hay funciones ni base de datos.

- `public/index.html`: página de inicio (marketing) que enlaza a la app.
- `public/app.html`: la app completa (CSS + JS en línea). Tres pestañas: Convertir PDF, Leer EPUB, Mi biblioteca; el lector es un overlay (`#readerOverlay`).
- `public/service-worker.js`: precarga del app shell y de `vendor/`. Las navegaciones se sirven **primero desde la caché** y se actualizan en segundo plano; todas las peticiones tienen tiempo límite (4 s, 3 s las externas) para que, con datos móviles "conectados" pero sin Internet real, la app no se quede esperando. La instalación solo exige los archivos esenciales (`OPTIONAL` en el SW lista los que pueden faltar). **Sube `CACHE_NAME` cada vez que cambies archivos del shell.**
- Las fuentes de Google (Fraunces/Inter) se cargan sin bloquear el dibujado (`media="print" onload`); si no cargan, se usa la fuente de reserva. No vuelvas a poner un `<link rel="stylesheet">` externo bloqueante: fue la causa de que la app tardara ~30 s en abrir sin Internet real. Los iconos son SVG en línea (`.ui-icon`), sin emojis.
- `public/vendor/`: copias locales de PDF.js 3.11.174 (`pdf.min.js`, `pdf.worker.min.js`) y JSZip 3.10.1. Se sirven en local (no desde un CDN) para que la conversión funcione offline.
- `public/manifest.json`, iconos: metadatos de la PWA.

## Datos
- IndexedDB `pdfEpubLibrary`, store `books`: `{ id, title, chapters: [{title, html}], wrapChapters, savedAt }`. `wrapChapters: true` significa que al leer hay que anteponer un `<h2>` con el título del capítulo (libros convertidos desde PDF).
- localStorage: `pdfEpubReaderFontSize` y `pdfEpubPos:<id>` (`{idx, scroll}`) con la posición de lectura.

## Convenciones y decisiones
- La interfaz y los comentarios del código están en español.
- PDF → párrafos: `itemsToLines` agrupa los items de PDF.js por coordenada Y; `linesToParagraphs` corta un párrafo cuando el salto vertical supera ~1,45× el interlineado mediano o cambia el tamaño de letra, y une las palabras cortadas con guion.
- El HTML de un EPUB pasa por `sanitizeDoc` (quita scripts y handlers `on*`) antes de insertarse con `innerHTML`.
- Netlify tiene pretty URLs (`/app.html` → `/app`); el service worker guarda copias sin redirección para ambas rutas.
- `getDocument` se llama con `isEvalSupported: false` (mitigación de CVE-2024-4367 en PDF.js 3.11.x). Pendiente: actualizar PDF.js a ≥ 4.2.67.
- El texto pasa por `escapeXml`, que elimina caracteres de control ilegales en XML.
- El EPUB abierto en la pestaña "Leer un EPUB" se guarda desde `openedEpubBook`, no desde las variables del lector (`epubChapters`), que se comparten con los PDF convertidos y la biblioteca.
- Conversión PDF: capítulos desde los marcadores del PDF (`getOutline`; si no hay, grupos de páginas); título/autor desde los metadatos si el usuario no los escribió; selector de idioma (`dc:language`); `stripRunningHeaders` quita cabeceras, pies y números de página repetidos; se unen los párrafos cortados por un salto de página; se pide contraseña si el PDF está protegido; el EPUB se genera con DEFLATE (el `mimetype` va sin comprimir).
- Lector de EPUB: títulos de capítulo desde `nav.xhtml`/`toc.ncx`; las rutas se decodifican (`%20`); `sanitizeDoc` quita `<style>`, estilos de posición e imágenes remotas; los enlaces internos funcionan (cada capítulo guarda su `path`); la posición se guarda como fracción de scroll; el botón Atrás y Escape cierran el lector (`history.pushState`).
- PWA: aviso "Hay una versión nueva" al actualizarse el service worker; navegación con tiempo límite de 4 s antes de usar la caché; icono `maskable` aparte y sin bloqueo de orientación.
- Instalación: `app.html` muestra una barra "Instalar app" cuando el navegador dispara `beforeinstallprompt`, instrucciones para Safari/iOS y un aviso si se abre en un navegador integrado (WhatsApp, Instagram…). No aparece si la app ya se abrió como app instalada.
- No hay OCR: los PDF escaneados dan un resultado casi vacío.
