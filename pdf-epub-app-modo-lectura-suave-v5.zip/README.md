# PDF → EPUB

Aplicación web (PWA) para convertir archivos PDF en libros EPUB y leerlos directamente en el navegador, incluso sin conexión a internet.

## Qué hace

- **Convertir PDF**: extrae el texto del PDF, lo reagrupa en párrafos y capítulos, y genera un `.epub` (EPUB 3 con índice NCX/nav) que también se puede descargar como página HTML.
- **Leer EPUB**: abre cualquier `.epub` estándar (sin DRM) con navegación por capítulos y tamaño de letra ajustable.
- **Mi biblioteca**: guarda los libros en el dispositivo (IndexedDB) y recuerda por dónde ibas leyendo.
- **Sin conexión**: un service worker guarda la app y sus librerías, así que funciona offline después de la primera visita y se puede instalar en la pantalla de inicio.
- **Privada**: todo ocurre en el dispositivo; ningún archivo se sube a un servidor.

## Tecnologías

HTML, CSS y JavaScript sin framework ni paso de compilación · [PDF.js](https://mozilla.github.io/pdf.js/) 3.11 · [JSZip](https://stuk.github.io/jszip/) 3.10 · Service Worker + Web App Manifest · IndexedDB · Netlify (hosting estático).

## Ejecutar en local

```bash
netlify dev --port 8889
# o cualquier servidor estático sobre la carpeta public/, por ejemplo:
npx serve public
```

El service worker necesita `http://localhost` o HTTPS.
